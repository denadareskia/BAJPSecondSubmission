package com.idcamp.bajpsecondsubmission.data.repository

import android.util.Log
import com.idcamp.bajpsecondsubmission.BuildConfig
import com.idcamp.bajpsecondsubmission.data.api.ApiConfig
import com.idcamp.bajpsecondsubmission.data.api.response.*
import com.idcamp.bajpsecondsubmission.utils.EspressoIdlingResource
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RemoteDataSource {
    fun getMovie(callback: LoadMovieCallback) {
        EspressoIdlingResource.increment()
        val client = ApiConfig.getApiService().loadMovie(BuildConfig.KEY)
        client.enqueue(object : Callback<MovieResponse> {
            override fun onResponse(
                call: Call<MovieResponse>,
                response: Response<MovieResponse>
            ) {
                if (response.isSuccessful) {
                    callback.onMovieReceived(response.body()?.results as List<MovieResultsItem>)
                } else {
                    Log.e(TAG, "onResponse: ${response.message()}")
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<MovieResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }
        })
    }

    fun getMovieDetail(movieId: Int, callback: LoadMovieDetailCallback) {
        EspressoIdlingResource.increment()
        val client = ApiConfig.getApiService().loadMovieDetail(movieId, BuildConfig.KEY)
        client.enqueue(object : Callback<MovieDetailResponse> {
            override fun onResponse(
                call: Call<MovieDetailResponse>,
                response: Response<MovieDetailResponse>
            ) {
                if (response.isSuccessful) {
                    callback.onMovieDetailReceived(response.body() as MovieDetailResponse)
                } else {
                    Log.e(TAG, "onResponse: ${response.message()}")
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<MovieDetailResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }
        })
    }

    fun getTv(callback: LoadTvCallback) {
        EspressoIdlingResource.increment()
        val client = ApiConfig.getApiService().loadTv(BuildConfig.KEY)
        client.enqueue(object : Callback<TvShowResponse> {
            override fun onResponse(
                call: Call<TvShowResponse>,
                response: Response<TvShowResponse>
            ) {
                if (response.isSuccessful) {
                    callback.onTvReceived(response.body()?.results as List<TvShowResultsItem>)
                } else {
                    Log.e(TAG, "onResponse: ${response.message()}")
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<TvShowResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }
        })
    }

    fun getTvDetail(tvId: Int, callback: LoadTvDetailCallback) {
        EspressoIdlingResource.increment()
        val client = ApiConfig.getApiService().loadTVDetail(tvId, BuildConfig.KEY)
        client.enqueue(object : Callback<TvShowDetailResponse> {
            override fun onResponse(
                call: Call<TvShowDetailResponse>,
                response: Response<TvShowDetailResponse>
            ) {
                if (response.isSuccessful) {
                    callback.onTvDetailReceived(response.body() as TvShowDetailResponse)
                } else {
                    Log.e(TAG, "onResponse: ${response.message()}")
                }
                EspressoIdlingResource.decrement()
            }

            override fun onFailure(call: Call<TvShowDetailResponse>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message.toString()}")
                EspressoIdlingResource.decrement()
            }
        })
    }

    interface LoadMovieCallback {
        fun onMovieReceived(movieResponse: List<MovieResultsItem>)
    }

    interface LoadMovieDetailCallback {
        fun onMovieDetailReceived(movieDetailResponse: MovieDetailResponse)
    }

    interface LoadTvCallback {
        fun onTvReceived(tvResponse: List<TvShowResultsItem>)
    }

    interface LoadTvDetailCallback {
        fun onTvDetailReceived(tvDetailResponse: TvShowDetailResponse)
    }

    companion object {
        const val TAG = "RemoteDataSource"

        @Volatile
        private var instance: RemoteDataSource? = null

        fun getInstance(): RemoteDataSource =
            instance ?: synchronized(this) {
                instance ?: RemoteDataSource().apply { instance = this }
            }
    }
}