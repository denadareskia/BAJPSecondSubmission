package com.idcamp.bajpsecondsubmission.utils

import com.idcamp.bajpsecondsubmission.data.CatalogueEntity
import com.idcamp.bajpsecondsubmission.data.MovieEntity
import com.idcamp.bajpsecondsubmission.data.TvShowEntity
import com.idcamp.bajpsecondsubmission.data.api.response.*

object DataDummy {
    fun generateMovie(): List<CatalogueEntity> {
        val catalogues = ArrayList<CatalogueEntity>()

        catalogues.add(
            CatalogueEntity(
                634649,
                "Spider-Man: No Way Home",
                8.5,
                "Peter Parker is unmasked and no longer able to separate his normal life from the high-stakes of being a super-hero. When he asks for help from Doctor Strange the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.",
                "/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg"
            )
        )
        return catalogues
    }

    fun generateTvShow(): List<CatalogueEntity> {
        val catalogues = ArrayList<CatalogueEntity>()

        catalogues.add(
            CatalogueEntity(
                85552,
                "Euphoria",
                8.4,
                "A group of high school students navigate love and friendships in a world of drugs, sex, trauma, and social media.",
                "/jtnfNzqZwN4E32FGGxx1YZaBWWf.jpg"
            )
        )
        return catalogues
    }

    fun generateMovieDetail(): MovieEntity = MovieEntity(
        634649,
        "Spider-Man: No Way Home",
        "2021-12-15",
        "Action, Adventure, Science Fiction",
        "148 minutes",
        "The Multiverse unleashed.",
        "Peter Parker is unmasked and no longer able to separate his normal life from the high-stakes of being a super-hero. When he asks for help from Doctor Strange the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.",
        8.5,
        "/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
        "/1Rr5SrvHxMXHu5RjKpaMba8VTzi.jpg"
    )

    fun generateTvShowDetail(): TvShowEntity = TvShowEntity(
        85552,
        "Euphoria",
        "2019-06-16 - 2022-01-23",
        "Drama",
        "60 minutes",
        "Remember this feeling.",
        14,
        2,
        "A group of high school students navigate love and friendships in a world of drugs, sex, trauma, and social media.",
        8.4,
        "/jtnfNzqZwN4E32FGGxx1YZaBWWf.jpg",
        "/oKt4J3TFjWirVwBqoHyIvv5IImd.jpg"
    )

    fun generateRemoteMovie(): List<MovieResultsItem> {
        val catalogues = ArrayList<MovieResultsItem>()

        catalogues.add(
            MovieResultsItem(
                "Peter Parker is unmasked and no longer able to separate his normal life from the high-stakes of being a super-hero. When he asks for help from Doctor Strange the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.",
                "Spider-Man: No Way Home",
                "/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
                8.5,
                634649
            )
        )
        return catalogues
    }

    fun generateRemoteTvShow(): List<TvShowResultsItem> {
        val catalogues = ArrayList<TvShowResultsItem>()

        catalogues.add(
            TvShowResultsItem(
                "A group of high school students navigate love and friendships in a world of drugs, sex, trauma, and social media.",
                "Euphoria",
                "/jtnfNzqZwN4E32FGGxx1YZaBWWf.jpg",
                8.4,
                85552
            )
        )
        return catalogues
    }

    fun generateRemoteMovieDetail(): MovieDetailResponse {
        val genres = ArrayList<GenresItem>()
        genres.add(GenresItem("Action"))
        genres.add(GenresItem("Adventure"))
        genres.add(GenresItem("Science Fiction"))

        return MovieDetailResponse(
            634649,
            "Spider-Man: No Way Home",
            "2021-12-15",
            genres,

            148,
            "The Multiverse unleashed.",
            "Peter Parker is unmasked and no longer able to separate his normal life from the high-stakes of being a super-hero. When he asks for help from Doctor Strange the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.",
            8.5,
            "/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
            "/1Rr5SrvHxMXHu5RjKpaMba8VTzi.jpg"
        )
    }

    fun generateRemoteTvShowDetail(): TvShowDetailResponse {
        val genres = ArrayList<GenresItem>()
        genres.add(GenresItem("Drama"))

        val runtime = listOf(60)

        return TvShowDetailResponse(
            85552,
            "Euphoria",
            "2019-06-16",
            "2022-01-23",
            genres,
            runtime,
            "Remember this feeling.",
            14,
            2,
            "A group of high school students navigate love and friendships in a world of drugs, sex, trauma, and social media.",
            8.4,
            "/jtnfNzqZwN4E32FGGxx1YZaBWWf.jpg",
            "/oKt4J3TFjWirVwBqoHyIvv5IImd.jpg"
        )
    }
}