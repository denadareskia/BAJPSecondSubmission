package com.idcamp.bajpsecondsubmission.ui.movie

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.idcamp.bajpsecondsubmission.data.CatalogueEntity
import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository

class MovieViewModel(private val catalogueRepository: CatalogueRepository) : ViewModel() {
    fun getMovies(): LiveData<List<CatalogueEntity>> = catalogueRepository.getMovie()
}