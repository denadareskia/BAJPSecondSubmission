package com.idcamp.bajpsecondsubmission.data.api

import com.idcamp.bajpsecondsubmission.data.api.response.MovieDetailResponse
import com.idcamp.bajpsecondsubmission.data.api.response.MovieResponse
import com.idcamp.bajpsecondsubmission.data.api.response.TvShowDetailResponse
import com.idcamp.bajpsecondsubmission.data.api.response.TvShowResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("movie/popular")
    fun loadMovie(
        @Query("api_key") api_key: String
    ): Call<MovieResponse>

    @GET("movie/{movieId}")
    fun loadMovieDetail(
        @Path("movieId") movieId: Int,
        @Query("api_key") api_key: String
    ): Call<MovieDetailResponse>

    @GET("tv/popular")
    fun loadTv(
        @Query("api_key") api_key: String
    ): Call<TvShowResponse>

    @GET("tv/{tvId}")
    fun loadTVDetail(
        @Path("tvId") tvId: Int,
        @Query("api_key") api_key: String
    ): Call<TvShowDetailResponse>
}