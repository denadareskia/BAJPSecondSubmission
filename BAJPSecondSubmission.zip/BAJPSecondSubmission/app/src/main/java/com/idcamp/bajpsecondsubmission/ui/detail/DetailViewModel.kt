package com.idcamp.bajpsecondsubmission.ui.detail

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.idcamp.bajpsecondsubmission.data.MovieEntity
import com.idcamp.bajpsecondsubmission.data.TvShowEntity
import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository

class DetailViewModel(private val catalogueRepository: CatalogueRepository) : ViewModel() {
    fun getMovieDetail(movieId: Int): LiveData<MovieEntity> =
        catalogueRepository.getMovieDetail(movieId)

    fun getTvShowDetail(tvId: Int): LiveData<TvShowEntity> = catalogueRepository.getTvDetail(tvId)
}