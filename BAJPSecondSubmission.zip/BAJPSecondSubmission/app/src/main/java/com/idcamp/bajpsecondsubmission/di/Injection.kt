package com.idcamp.bajpsecondsubmission.di

import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository
import com.idcamp.bajpsecondsubmission.data.repository.RemoteDataSource

object Injection {
    fun provideRepository(): CatalogueRepository {
        val remoteDataSource = RemoteDataSource.getInstance()
        return CatalogueRepository.getInstance(remoteDataSource)
    }
}