package com.idcamp.bajpsecondsubmission.data.repository

import androidx.lifecycle.LiveData
import com.idcamp.bajpsecondsubmission.data.CatalogueEntity
import com.idcamp.bajpsecondsubmission.data.MovieEntity
import com.idcamp.bajpsecondsubmission.data.TvShowEntity

interface CatalogueDataSource {
    fun getMovie(): LiveData<List<CatalogueEntity>>

    fun getMovieDetail(movieId: Int): LiveData<MovieEntity>

    fun getTv(): LiveData<List<CatalogueEntity>>

    fun getTvDetail(tvId: Int): LiveData<TvShowEntity>
}