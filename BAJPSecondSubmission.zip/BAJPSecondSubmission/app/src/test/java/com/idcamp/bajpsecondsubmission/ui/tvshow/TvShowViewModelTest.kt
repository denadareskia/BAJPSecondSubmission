package com.idcamp.bajpsecondsubmission.ui.tvshow

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.idcamp.bajpsecondsubmission.data.CatalogueEntity
import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository
import com.idcamp.bajpsecondsubmission.utils.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule

import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class TvShowViewModelTest {
    private lateinit var viewModel: TvShowViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogueRepository: CatalogueRepository

    @Mock
    private lateinit var observer: Observer<List<CatalogueEntity>>

    @Before
    fun setup() {
        viewModel = TvShowViewModel(catalogueRepository)
    }

    @Test
    fun getTvs() {
        val dummyTv = DataDummy.generateTvShow()
        val tv = MutableLiveData<List<CatalogueEntity>>()
        tv.value = dummyTv

        Mockito.`when`(catalogueRepository.getTv()).thenReturn(tv)
        val catalogueEntities = viewModel.getTvs().value
        Mockito.verify(catalogueRepository).getTv()
        assertNotNull(catalogueEntities)

        viewModel.getTvs().observeForever(observer)
        Mockito.verify(observer).onChanged(dummyTv)
    }
}