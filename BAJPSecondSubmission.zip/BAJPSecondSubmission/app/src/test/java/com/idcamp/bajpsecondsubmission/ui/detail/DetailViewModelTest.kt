package com.idcamp.bajpsecondsubmission.ui.detail

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.idcamp.bajpsecondsubmission.data.MovieEntity
import com.idcamp.bajpsecondsubmission.data.TvShowEntity
import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository
import com.idcamp.bajpsecondsubmission.utils.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule

import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class DetailViewModelTest {
    private lateinit var viewModel: DetailViewModel
    private val dummyMovies = DataDummy.generateMovieDetail()
    private val dummyTv = DataDummy.generateTvShowDetail()
    private val movieId = dummyMovies.id as Int
    private val tvId = dummyTv.id as Int
    private val wrongMovieId = 1

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogueRepository: CatalogueRepository

    @Mock
    private lateinit var movieObserver: Observer<MovieEntity>

    @Mock
    private lateinit var tvObserver: Observer<TvShowEntity>

    @Before
    fun setup() {
        viewModel = DetailViewModel(catalogueRepository)
    }

    @Test
    fun getDetailMovie() {
        val movieData = MutableLiveData<MovieEntity>()
        movieData.value = dummyMovies

        Mockito.`when`(catalogueRepository.getMovieDetail(movieId)).thenReturn(movieData)
        val movieEntity = viewModel.getMovieDetail(movieId).value as MovieEntity
        Mockito.verify(catalogueRepository).getMovieDetail(movieId)
        assertNotNull(movieEntity)
        assertEquals(dummyMovies.id, movieEntity.id)
        assertEquals(dummyMovies.genres, movieEntity.genres)
        assertEquals(dummyMovies.releaseDate, movieEntity.releaseDate)
        assertEquals(dummyMovies.backdrop, movieEntity.backdrop)
        assertEquals(dummyMovies.poster, movieEntity.poster)
        assertEquals(dummyMovies.tagline, movieEntity.tagline)
        assertEquals(dummyMovies.runtime, movieEntity.runtime)
        assertEquals(dummyMovies.overview, movieEntity.overview)
        assertEquals(dummyMovies.rating, movieEntity.rating)

        viewModel.getMovieDetail(movieId).observeForever(movieObserver)
        Mockito.verify(movieObserver).onChanged(dummyMovies)
    }

    @Test
    fun getDetailTv() {
        val tvData = MutableLiveData<TvShowEntity>()
        tvData.value = dummyTv

        Mockito.`when`(catalogueRepository.getTvDetail(tvId)).thenReturn(tvData)
        val tvEntity = viewModel.getTvShowDetail(tvId).value as TvShowEntity
        Mockito.verify(catalogueRepository).getTvDetail(tvId)
        assertNotNull(tvEntity)
        assertEquals(dummyTv.id, tvEntity.id)
        assertEquals(dummyTv.season, tvEntity.season)
        assertEquals(dummyTv.episode, tvEntity.episode)
        assertEquals(dummyTv.backdrop, tvEntity.backdrop)
        assertEquals(dummyTv.genres, tvEntity.genres)
        assertEquals(dummyTv.overview, tvEntity.overview)
        assertEquals(dummyTv.poster, tvEntity.poster)
        assertEquals(dummyTv.rating, tvEntity.rating)
        assertEquals(dummyTv.releaseDate, tvEntity.releaseDate)
        assertEquals(dummyTv.runtime, tvEntity.runtime)
        assertEquals(dummyTv.tagline, tvEntity.tagline)
        assertEquals(dummyTv.title, tvEntity.title)

        viewModel.getTvShowDetail(tvId).observeForever(tvObserver)
        Mockito.verify(tvObserver).onChanged(dummyTv)
    }

    @Test
    fun emptyDetail() {
        val movieData = MutableLiveData<MovieEntity>()

        Mockito.`when`(catalogueRepository.getMovieDetail(wrongMovieId)).thenReturn(movieData)
        val movieEntity = viewModel.getMovieDetail(wrongMovieId).value
        Mockito.verify(catalogueRepository).getMovieDetail(wrongMovieId)
        assertNull(movieEntity)
    }
}