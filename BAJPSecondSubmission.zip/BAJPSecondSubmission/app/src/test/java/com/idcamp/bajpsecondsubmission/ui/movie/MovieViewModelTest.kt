package com.idcamp.bajpsecondsubmission.ui.movie

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import com.idcamp.bajpsecondsubmission.data.CatalogueEntity
import com.idcamp.bajpsecondsubmission.data.repository.CatalogueRepository
import com.idcamp.bajpsecondsubmission.utils.DataDummy
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule

import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class MovieViewModelTest {
    private lateinit var viewModel: MovieViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Mock
    private lateinit var catalogueRepository: CatalogueRepository

    @Mock
    private lateinit var observer: Observer<List<CatalogueEntity>>

    @Before
    fun setup() {
        viewModel = MovieViewModel(catalogueRepository)
    }

    @Test
    fun getMovies() {
        val dummyMovie = DataDummy.generateMovie()
        val movie = MutableLiveData<List<CatalogueEntity>>()
        movie.value = dummyMovie

        Mockito.`when`(catalogueRepository.getMovie()).thenReturn(movie)
        val catalogueEntities = viewModel.getMovies().value
        Mockito.verify(catalogueRepository).getMovie()
        assertNotNull(catalogueEntities)

        viewModel.getMovies().observeForever(observer)
        Mockito.verify(observer).onChanged(dummyMovie)
    }
}